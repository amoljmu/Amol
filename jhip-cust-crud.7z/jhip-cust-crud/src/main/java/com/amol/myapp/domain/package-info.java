/**
 * JPA domain objects.
 */
package com.amol.myapp.domain;
