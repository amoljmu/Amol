/**
 * Spring Security configuration.
 */
package com.amol.myapp.security;
