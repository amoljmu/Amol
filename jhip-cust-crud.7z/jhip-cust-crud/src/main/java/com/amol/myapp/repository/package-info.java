/**
 * Spring Data JPA repositories.
 */
package com.amol.myapp.repository;
