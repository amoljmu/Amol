/**
 * Spring MVC REST controllers.
 */
package com.amol.myapp.web.rest;
