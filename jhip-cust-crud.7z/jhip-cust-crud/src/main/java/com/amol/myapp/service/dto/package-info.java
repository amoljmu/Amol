/**
 * Data Transfer Objects.
 */
package com.amol.myapp.service.dto;
