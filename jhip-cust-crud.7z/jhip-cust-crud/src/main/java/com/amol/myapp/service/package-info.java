/**
 * Service layer beans.
 */
package com.amol.myapp.service;
